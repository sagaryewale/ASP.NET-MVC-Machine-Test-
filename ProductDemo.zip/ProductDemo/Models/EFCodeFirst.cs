﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Web;

namespace ProductDemo.Models
{
    public class EFCodeFirst : DbContext
    {
        public DbSet<CategoryTable> CategoryTable { get; set; }
        public DbSet<ProductTable> ProductTable { get; set; }


    }
}